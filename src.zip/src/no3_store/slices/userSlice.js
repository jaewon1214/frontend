import { createSlice } from "@reduxjs/toolkit"



const initialUsers = [
  {id: 1, username: "john", password: "1111"},
  {id: 2, username: "peter", password: "1111"},
  {id: 3, username: "susan", password: "1111"},
  {id: 4, username: "sue", password: "1111"},
]


const initalState = {
  users : initialUsers,
  username : "",
  islogin : false
}

const userSlice = createSlice({
    name : "userSlice",
    initalState,
    reducers : {
        Login : (state, action) => {
            islogin : true,
            username : action.payload.username
        }
    }
})


const reducer = (state, action) =>{
    switch(action.type){
        case "Login" :
            return{
                ...state,
                islogin : true,
                username : action.payload.username
            }
        case "Register" :
            return{
                ...state,
                users: [
                    ...state.users,
                    {
                        id: action.payload.id,
                        username : action.payload.user.username,
                        password : action.payload.user.password
                    }
                ]
            }
        case "Logout" :
            return{
                ...state,
                islogin : false,
                username : ""
            }
        default :
            return state
    }
}

