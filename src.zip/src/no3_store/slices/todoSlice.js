import { createSlice } from "@reduxjs/toolkit"


const initalObj = {id : "", subject : "", checked : false}

const initalState = {
  todoList : [
    {id : 1, subject : "HTML 공부", checked : true},
    {id : 2, subject : "CSS 공부", checked : false},
    {id : 3, subject : "React 공부", checked : true},
    {id : 4, subject : "Python 공부", checked : false},
  ],
  todoObj : initalObj
}

const todoSlice = createSlice({
    name : "todoSlice", 
    initialState,
    reducers : {
        remove : (state, action) => {
            state.todoList = state.todoList.filter(todo=>
                (todo.id !== action.payload)
            )
        },
        Updata : (state, action) =>{
            state.todoList = state.todoList.map(todo=>(
                todo.id === action.payload.id ?
                    {...todo, subject: action.payload.value}
                    :todo
            ))
        },
        Toggle : (state, action) =>{
            state.todoList = state.todoList.map(todo=>(
                todo.id === action.payload ?
                    { todo, checked: !todo.checked }
                    :todo
            ))
        },
        change : (state, action) =>{
            state.todoObj = {
                ...state.todoObj,
                [action.payload.name] : action.payload.value
            }
        },
        Register : (state) =>{
            state.todoList = [
                ...state.todoList,
                {
                    ...state.todoList,
                    id: state.todoList.length>0 ?
                        Math.max(...state.todoList.map(todo=>todo.id)) +1
                        : 1
                }
            ],
            state.todoObj = initalObj
        }
    }
})


export const {remove, Updata, Toggle, change, Register} = todoSlice.actions;
export default todoSlice.reducer;